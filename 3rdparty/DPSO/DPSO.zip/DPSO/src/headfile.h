#ifndef __HEADFILE_H__
#define __HEADFILE_H__

//#include <graphics.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>            	
#include <time.h>						//YS 01/16/98
                                              
#endif
