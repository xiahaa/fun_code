#ifndef __MYFUN_H__
#define __MYFUN_H__

extern float f6(FMATRIX, int a);
extern float sphere(FMATRIX, int a, int b);
extern float rosenbrock(FMATRIX, int a,int b);
extern float rastrigrin(FMATRIX, int a, int b);
extern float griewank(FMATRIX, int a,int b);
extern float ackley(FMATRIX, int a,int b);
extern float mf2(FMATRIX, int a,int b);
extern float mf8(FMATRIX, int a);

#endif

